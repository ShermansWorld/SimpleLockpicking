SimpleLockpicking Resourcepack by ShermansWorld - VERSION 1.0 - 4/1/2023
Textures created by iCeleste

Resource pack includes:
- lockpick texture
- lockpick model

This is an optional resource pack add-on to the SimpleLockpicking plugin, authored by ShermansWorld.
You do not need to request permission to modify this resource pack, or include it in any other packs.
You may see an "Incompatible" warning, this can most likely be ignored as this is determined by the
"pack.mcmeta" file and not the contents of the resourcepack.
